//
//  TableViewCell.swift
//  ImageSlideshow
//
//  Created by iosMaher on 4/10/17.
//  Copyright © 2017 CocoaPods. All rights reserved.
//

import UIKit
import ImageSlideshow

class TableViewCell: UITableViewCell {

    @IBOutlet weak var imageSlider: ImageSlideshow!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)


    }

}
