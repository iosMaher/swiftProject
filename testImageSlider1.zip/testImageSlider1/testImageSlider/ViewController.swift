//
//  ViewController.swift
//  ImageSlideshow
//
//  Created by Petr Zvoníček on 30.07.15.
//  Copyright (c) 2015 Petr Zvonicek. All rights reserved.
//

import UIKit
import ImageSlideshow

class ViewController: UIViewController , UITableViewDataSource , UITableViewDelegate {

    open override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    @IBOutlet weak var tableView: UITableView!
  
    let kingfisherSource = [KingfisherSource(urlString: "https://images.unsplash.com/photo-1432679963831-2dab49187847?w=1080")!, KingfisherSource(urlString: "https://images.unsplash.com/photo-1447746249824-4be4e1b76d66?w=1080")!, KingfisherSource(urlString: "https://images.unsplash.com/photo-1463595373836-6e0b0a8ee322?w=1080")!]

    override func viewDidLoad() {
        super.viewDidLoad()

        

    }



    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "first", for: indexPath) as! TableViewCell

            cell.imageSlider.setImageInputs(kingfisherSource)
            cell.imageSlider.backgroundColor = UIColor.white
            cell.imageSlider.slideshowInterval = 3.0
            cell.imageSlider.pageControlPosition = PageControlPosition.underScrollView
            cell.imageSlider.pageControl.currentPageIndicatorTintColor = UIColor.lightGray
            cell.imageSlider.pageControl.pageIndicatorTintColor = UIColor.black
            cell.imageSlider.contentScaleMode = UIViewContentMode.scaleAspectFill
            cell.imageSlider.currentPageChanged = { page in
                
                
            }
            
            
            let recognizer = UITapGestureRecognizer(target: self, action: #selector(tap))
            cell.imageSlider.addGestureRecognizer(recognizer)
            
  
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "second", for: indexPath) as! TableViewCell

            cell.titleLabel.text = "Hello"
            cell.contentLabel.text = "World"
            
        return cell
        }
        
    }
    func tap() {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "first") as! TableViewCell

        cell.imageSlider.presentFullScreenController(from: self)
        
    }
    
}
